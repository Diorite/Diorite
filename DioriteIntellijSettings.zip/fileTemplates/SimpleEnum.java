#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import org.diorite.utils.SimpleEnum;
import org.diorite.utils.SimpleEnum.ASimpleEnum;

import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

@SuppressWarnings("ClassHasNoToStringMethod")
public class ${NAME} extends ASimpleEnum<${NAME}>
{
    static
    {
        init(${NAME}.class, ${enumSize});
    }
    
    public static final ${NAME} DEF = new ${NAME}("DEF");
    
    public ${NAME}(final String enumName, final int enumId)
    {
        super(enumName, enumId);
    }

    public ${NAME}(final String enumName)
    {
        super(enumName);
    }
    
    /**
     * Register new {@link ${NAME}} entry in this enum.
     *
     * @param element new element to register.
     */
    public static void register(final ${NAME} element)
    {
        ASimpleEnum.register(${NAME}.class, element);
    }

    /**
     * Get one of {@link ${NAME}} entry by its ordinal id.
     *
     * @param ordinal ordinal id of entry.
     *
     * @return one of entry or null.
     */
    public static ${NAME} getByEnumOrdinal(final int ordinal)
    {
        return getByEnumOrdinal(${NAME}.class, ordinal);
    }

    /**
     * Get one of ${NAME} entry by its name.
     *
     * @param name name of entry.
     *
     * @return one of entry or null.
     */
    public static ${NAME} getByEnumName(final String name)
    {
        return getByEnumName(${NAME}.class, name);
    }

    /**
     * @return all values in array.
     */
    public static ${NAME}[] values()
    {
        final TIntObjectMap<SimpleEnum<?>> map = getByEnumOrdinal(${NAME}.class);
        return (${NAME}[]) map.values(new ${NAME}[map.size()]);
    }

    static
    {
        ${NAME}.register(DEF);
    }
}